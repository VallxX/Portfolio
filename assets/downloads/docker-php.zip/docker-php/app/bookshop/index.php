<?php

require_once './php/bibli_generale.php';
require_once './php/bibli_bookshop.php';

// Bufferisation des sorties
ob_start();
$bd = bdConnect();

// Démarrage ou reprise de la session
session_start();

affDebutEnseigneEntete('BookShop | Bienvenue', '.');

affContenuL($bd);

affPiedFin();

/**
 * Affichage du contenu de la page
 *
 * @param resource $bd Connexion à la base de données
 * @return void
 */
function affContenuL($bd): void {
    echo
        '<h1>Bienvenue sur BookShop !</h1>',
        '<p>Passez la souris sur le logo et laissez-vous guider pour découvrir les dernières exclusivités de notre site.</p>',
        '<p>Nouveau venu sur BookShop ? Consultez notre <a href="./php/presentation.php">page de présentation</a> !</p>';
        
    // Requête pour obtenir les 4 derniers livres ajoutés avec tous leurs auteurs
    $sql1 = "SELECT livre.liID, livre.liTitre, editeur.edNom,
             GROUP_CONCAT(CONCAT(auteur.auPrenom, '|', auteur.auNom) SEPARATOR '@') AS auteurs
             FROM livre
             JOIN editeur ON livre.liIDEditeur = editeur.edID
             JOIN aut_livre ON livre.liID = aut_livre.al_IDLivre
             JOIN auteur ON aut_livre.al_IDAuteur = auteur.auID
             GROUP BY livre.liID
             ORDER BY livre.liID DESC
             LIMIT 4";
    $res1 = bdSendRequest($bd, $sql1);
    $livres1 = [];
    while ($t = mysqli_fetch_assoc($res1)) {
        $auteurs = [];
        if (!empty($t['auteurs'])) {
            $auteursBruts = explode('@', $t['auteurs']);
            foreach ($auteursBruts as $auteur) {
                list($prenom, $nom) = explode('|', $auteur);
                $auteurs[] = ['prenom' => $prenom, 'nom' => $nom];
            }
        }
        $livres1[] = [
            'liID'    => $t['liID'],
            'Titre'   => $t['liTitre'],
            'auteurs' => $auteurs
        ];
    }
    $p = 'Voici les 4 derniers livres ajoutés :';
    affSectionLivresL('Dernières nouveautés', $p, $livres1);
    
    // Requête pour obtenir les 4 livres les plus vendus avec leurs auteurs
    $sql2 = "SELECT livre.liID, livre.liTitre, editeur.edNom,
            GROUP_CONCAT(DISTINCT CONCAT(auteur.auPrenom, '|', auteur.auNom) SEPARATOR '@') AS auteurs,
            (COUNT(compo_commande.ccIDLivre)*compo_commande.ccQuantite) AS total_vendu
            FROM livre
            JOIN editeur ON livre.liIDEditeur = editeur.edID
            JOIN aut_livre ON livre.liID = aut_livre.al_IDLivre
            JOIN auteur ON aut_livre.al_IDAuteur = auteur.auID
            JOIN compo_commande ON livre.liID = compo_commande.ccIDLivre
            JOIN commande ON compo_commande.ccIDCommande = commande.coID
            GROUP BY livre.liID
            ORDER BY total_vendu DESC
            LIMIT 4";
    $res2 = bdSendRequest($bd, $sql2);
    $livres2 = [];
    while ($t = mysqli_fetch_assoc($res2)) {
        $auteurs = [];
        if (!empty($t['auteurs'])) {
            $auteursBruts = explode('@', $t['auteurs']);
            foreach ($auteursBruts as $auteur) {
                list($prenom, $nom) = explode('|', $auteur);
                $auteurs[] = ['prenom' => $prenom, 'nom' => $nom];
            }
        }
        $livres2[] = [
            'liID'      => $t['liID'],
            'Titre'     => $t['liTitre'],
            'auteurs'   => $auteurs,
            'total_vendu' => $t['total_vendu']
        ];
    }
    affSectionLivresL('Top des ventes', 'Voici les 4 articles les plus vendus :', $livres2);
    
    mysqli_free_result($res1);
    mysqli_free_result($res2);
    mysqli_close($bd);
    ob_end_flush();
}

/**
 * Affichage d'une section de livres
 *
 * @param string $h2     Titre de la section
 * @param string $p      Contenu de l'élément p
 * @param array  $livres Tableau contenant un élément pour chaque livre (avec id, titre et auteurs)
 *
 * @return void
 */
function affSectionLivresL(string $h2, string $p, array $livres): void {
    echo
        '<section>',
            '<h2>', htmlspecialchars($h2), '</h2>',
            '<p>', htmlspecialchars($p), '</p>';
    
    foreach ($livres as $t) {
        echo
            '<figure>',
                // Lien d'ajout au panier
                '<a class="addToCart" href="./php/panier.php?action=ajouter&amp;id=', $t['liID'], '" title="Ajouter au panier"></a>',
                '<a class="addToWishlist" href="#" title="Ajouter à la liste de cadeaux"></a>',
                '<a href="./php/details.php?article=', $t['liID'], '" title="Voir détails">',
                    '<img src="images/livres/', $t['liID'], '_mini.jpg" alt="', htmlspecialchars($t['Titre']), '">',
                '</a>',
                '<figcaption>';
        $i = 0;
        foreach ($t['auteurs'] as $auteur) {
            if ($i > 0) {
                echo ', ';
            }
            ++$i;
            echo '<a title="Rechercher l\'auteur" href="php/recherche.php?type=auteur&amp;quoi=', urlencode($auteur['nom']), '">',
                 htmlspecialchars(mb_substr($auteur['prenom'], 0, 1, 'UTF-8')), '. ', htmlspecialchars($auteur['nom']), '</a>';
        }
        echo '<br><strong>', htmlspecialchars($t['Titre']), '</strong>',
                '</figcaption>',
            '</figure>';
    }
    echo '</section>';
}