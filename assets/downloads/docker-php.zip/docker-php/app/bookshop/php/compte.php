<?php

// Configuration et initialisation
require_once('bibli_bookshop.php');
require_once('bibli_generale.php');

ob_start();
session_start();

// Vérification de l'authentification
if (!estAuthentifie()) {
    header('Location: ../index.php');
    exit();
}

// Traitement des soumissions
$erreursP = isset($_POST['btnUpdatePersonnel']) ? traitementUpdatePersonnel() : null;
$erreursL = isset($_POST['btnUpdateLivraison']) ? traitementUpdateLivraison() : null;


affDebutEnseigneEntete('BookShop | Votre Compte');

// Affichage des messages de succès
if (isset($erreursP) && empty($erreursP)) {
    echo '<p class="success">Modification réussie !</p>';
}

// Affichage des formulaires et historique
affPremFormulaireL($erreursP);
affSecFormulaireL($erreursL);
affHistoriqueL();

affPiedFin();
ob_end_flush();

function affPremFormulaireL(?array $errs): void {
    $userData = getUserData();
    
    $values = [
        'nom' => $_POST['nom'] ?? $userData['cliNom'],
        'prenom' => $_POST['prenom'] ?? $userData['cliPrenom'],
        'email' => $_POST['email'] ?? $userData['cliEmail'],
        'telephone' => $_POST['telephone'] ?? $userData['cliTelephone'],
        'password' => ''
    ];

    echo '<form method="post" action="', htmlspecialchars($_SERVER['PHP_SELF']), '">',
            '<section>';

    displayErrors($errs);

    echo    '<h1>Bonjour ' . htmlspecialchars($userData["cliPrenom"]) . '</h1>',
            '<h2>Modifier vos informations personnelles</h2>',
            '<p>Merci de remplir les informations suivantes (tous les champs sont obligatoires)</p>',
            '<table>';

    affLigneInput('Votre nom :', ['type' => 'text', 'name' => 'nom', 'value' => $values['nom'], 'required' => true]);
    affLigneInput('Votre prénom :', ['type' => 'text', 'name' => 'prenom', 'value' => $values['prenom'], 'required' => true]);
    affLigneInput('Votre adresse email :', [
        'type' => 'email', 
        'name' => 'email', 
        'value' => $values['email'],
        'placeholder' => 'xxx@yyy.zz', 
        'required' => true
    ]);
    affLigneInput('Votre numéro de téléphone :', [
        'type' => 'tel', 
        'name' => 'telephone', 
        'value' => $values['telephone'],
        'placeholder' => 'Format : 03.81.66.64.52', 
        'pattern' => '^(\d{2}\.){4}\d{2}$', 
        'required' => true
    ]);
    affLigneInput('Choisissez un mot de passe :', [
        'type' => 'password', 
        'name' => 'password', 
        'value' => $values['password'],
        'placeholder' => LMIN_PASSWORD . ' caractères minimum'
    ]);

    echo    '</table>',
            '</section>',
            '<section>',
                '<p><input type="submit" name="btnUpdatePersonnel" value="Modifier"></p>',
            '</section>',
        '</form>';
}

function affSecFormulaireL(?array $errs): void {
    $livraisonData = getLivraisonData();
    
    $values = [
        'adresse' => $_POST['adresse'] ?? $livraisonData['cliAdresse'],
        'CP' => $_POST['CP'] ?? $livraisonData['cliCP'],
        'ville' => $_POST['ville'] ?? $livraisonData['cliVille'],
        'pays' => $_POST['pays'] ?? $livraisonData['cliPays']
    ];

    echo '<form method="post" action="', htmlspecialchars($_SERVER['PHP_SELF']), '">',
            '<section>';

    displayErrors($errs);

    echo    '<h2>Modifier vos informations de livraison</h2>',
            '<p>Merci de remplir les informations suivantes (tous les champs sont obligatoires)</p>',
            '<table>';

    affLigneInput('Votre adresse:', ['type' => 'text', 'name' => 'adresse', 'value' => $values['adresse'], 'required' => true]);
    affLigneInput('Votre Code Postal :', ['type' => 'text', 'name' => 'CP', 'value' => $values['CP'], 'required' => true]);
    affLigneInput('Votre ville :', [
        'type' => 'text', 
        'name' => 'ville', 
        'value' => $values['ville'],
        'placeholder' => 'Exemple : Besançon', 
        'required' => true
    ]);
    affLigneInput('Votre Pays :', [
        'type' => 'text', 
        'name' => 'pays', 
        'value' => $values['pays'],
        'placeholder' => 'Exemple : France', 
        'required' => true
    ]);

    echo    '</table>',
            '</section>',
            '<section>',
                '<p><input type="submit" name="btnUpdateLivraison" value="Modifier"></p>',
            '</section>',
        '</form>';
}

function affLivreL(array $livre): void {
    $auteurs = array_map(function($auteur) {
        list($prenom, $nom) = explode('|', $auteur);
        return [
            'prenom' => htmlspecialchars($prenom),
            'nom' => htmlspecialchars($nom),
            'url' => urlencode($nom)
        ];
    }, explode('@', $livre['auteurs']));

    $livre = htmlProtegerSorties($livre);
    
    echo '<article class="arCommande">',
            '<a href="details.php?article=', $livre['liID'], '" title="Voir détails">',
                '<img src="../images/livres/', $livre['liID'], '_mini.jpg" alt="', $livre['liTitre'], '">',
            '</a>',
            '<h5>', $livre['liTitre'], '</h5>',
            'Écrit par : ';
    
    foreach ($auteurs as $i => $auteur) {
        echo $i > 0 ? ', ' : '', 
             '<a href="', htmlspecialchars($_SERVER['PHP_SELF']), '?type=auteur&amp;quoi=', $auteur['url'], '">',
             $auteur['prenom'], ' ', $auteur['nom'], '</a>';
    }

    echo    '<br>Éditeur : <a class="lienExterne" href="http://', $livre['edWeb'], '" target="_blank">', $livre['edNom'], '</a><br>',
            'Prix : ', $livre['liPrix'], ' &euro;<br>',
            'Pages : ', $livre['liNbPages'], '<br>',
            'ISBN13 : ', $livre['liISBN13'],
            '<p class="commande-quantity"><strong>Quantité : ', $livre["ccQuantite"], '</strong></p>',
        '</article>';
}

function affHistoriqueL(): void {
    echo '<h2>Historique des commandes</h2>';
    $bd = bdConnect();
    
    $commandes = getCommandes($bd);
    
    if (empty($commandes)) {
        echo '<p>Aucune commande effectuée.</p>';
        return;
    }

    foreach ($commandes as $commande) {
        displayCommande($bd, $commande);
    }
    
    mysqli_close($bd);
}

function traitementUpdatePersonnel(): array {
    if (!parametresControle('post', ['nom', 'prenom', 'email', 'telephone', 'password', 'btnUpdatePersonnel'])) {
        header('Location: ./compte.php');
        exit();
    }

    $erreurs = [];
    $fields = [
        'nom' => ['label' => 'Le nom', 'max' => LMAX_NOM, 'pattern' => '/^[[:alpha:]]([\' -]?[[:alpha:]]+)*$/u'],
        'prenom' => ['label' => 'Le prénom', 'max' => LMAX_PRENOM, 'pattern' => '/^[[:alpha:]]([\' -]?[[:alpha:]]+)*$/u'],
        'email' => ['label' => 'L\'adresse email', 'max' => LMAX_EMAIL],
        'telephone' => ['label' => 'Le numéro de téléphone', 'max' => LMAX_TELEPHONE, 'pattern' => '/^(\\d{2}\\.){4}\\d{2}$/u']
    ];

    // Validation des champs
    foreach ($fields as $field => $config) {
        $value = trim($_POST[$field]);
        verifierTexte($value, $config['label'], $erreurs, $config['max'], $config['pattern'] ?? null);
    }

    // Validation spécifique de l'email
    if (!filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL)) {
        $erreurs[] = 'L\'adresse email n\'est pas valide.';
    }

    // Validation du mot de passe
    if (!empty($_POST['password']) && mb_strlen($_POST['password'], 'UTF-8') < LMIN_PASSWORD) {
        $erreurs[] = 'Le mot de passe doit être constitué d\'au moins '. LMIN_PASSWORD . ' caractères.';
    }

    if (!empty($erreurs)) {
        return $erreurs;
    }

    // Vérification de l'unicité de l'email
    $bd = bdConnect();
    $email = mysqli_real_escape_string($bd, trim($_POST['email']));
    
    if (emailExists($bd, $email)) {
        $erreurs[] = 'L\'adresse email est déjà utilisée.';
        mysqli_close($bd);
        return $erreurs;
    }

    // Préparation des données pour la mise à jour
    $data = [
        'cliEmail' => $email,
        'cliTelephone' => mysqli_real_escape_string($bd, trim($_POST['telephone'])),
        'cliPrenom' => mysqli_real_escape_string($bd, trim($_POST['prenom'])),
        'cliNom' => mysqli_real_escape_string($bd, trim($_POST['nom']))
    ];

    // Gestion du mot de passe
    if (!empty($_POST['password'])) {
        $data['cliPassword'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
    } else {
        $currentPass = getCurrentPassword($bd);
        $data['cliPassword'] = $currentPass;
    }

    // Mise à jour en base de données
    updateUserData($bd, $data);
    mysqli_close($bd);

    return [];
}

function traitementUpdateLivraison(): array {
    if (!parametresControle('post', ['adresse', 'CP', 'ville', 'pays', 'btnUpdateLivraison'])) {
        return [];
    }

    $erreurs = [];
    $fields = [
        'adresse' => ['max' => 100],
        'CP' => ['max' => 5],
        'ville' => ['max' => 50],
        'pays' => ['max' => 14]
    ];

    // Vérification que l'adresse n'est pas vide
    if (empty(trim($_POST['adresse']))) {
        $erreurs[] = "L'adresse de livraison doit être renseignée.";
    }

    // Validation des champs
    foreach ($fields as $field => $config) {
        $value = trim($_POST[$field]);
        if (mb_strlen($value, 'UTF-8') > $config['max']) {
            $erreurs[] = "Le champ $field est trop long.";
        }
    }

    // Validation spécifique du code postal
    if (!is_numeric(trim($_POST['CP']))) {
        $erreurs[] = "Le code postal n'est pas au format d'un nombre.";
    }

    if (!empty($erreurs)) {
        return $erreurs;
    }

    // Mise à jour en base de données
    $bd = bdConnect();
    $data = [
        'cliAdresse' => mysqli_real_escape_string($bd, trim($_POST['adresse'])),
        'cliCP' => mysqli_real_escape_string($bd, trim($_POST['CP'])),
        'cliVille' => mysqli_real_escape_string($bd, trim($_POST['ville'])),
        'cliPays' => mysqli_real_escape_string($bd, trim($_POST['pays']))
    ];

    updateUserData($bd, $data);
    mysqli_close($bd);

    return [];
}


function getUserData(): array {
    $bd = bdConnect();
    $query = "SELECT cliNom, cliPrenom, cliTelephone, cliEmail FROM client WHERE cliID = " . $_SESSION["cliID"];
    $result = bdSendRequest($bd, $query);
    return mysqli_fetch_assoc($result);
}

function getLivraisonData(): array {
    $bd = bdConnect();
    $query = "SELECT cliAdresse, cliCP, cliVille, cliPays FROM client WHERE cliID = " . $_SESSION["cliID"];
    $result = bdSendRequest($bd, $query);
    return mysqli_fetch_assoc($result);
}

function displayErrors(?array $errors): void {
    if (!empty($errors)) {
        echo '<p class="error"><strong>Les erreurs suivantes ont été relevées :</strong>';
        foreach ($errors as $error) {
            echo '<br>- ', htmlspecialchars($error);
        }
        echo '</p>';
    }
}

function getCommandes(mysqli $bd): array {
    $request = "SELECT * FROM commande WHERE coIDClient = " . $_SESSION['cliID'];
    $result = bdSendRequest($bd, $request);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function displayCommande(mysqli $bd, array $commande): void {
    $date = $commande['coDate'];
    $formattedDate = substr($date, 6, 2) . '/' . substr($date, 4, 2) . '/' . substr($date, 0, 4) . 
                     ' à ' . substr($date, 8, 2) . ':' . substr($date, 10, 2);

    echo '<section class="commande">';
    echo "<h3>Commande effectuée le $formattedDate</h3>";

    $livres = getCommandeLivres($bd, $commande['coID']);
    $prixTotal = 0;

    foreach ($livres as $livre) {
        $prixTotal += $livre['ccQuantite'] * $livre['liPrix'];
        affLivreL($livre);
    }

    echo "<h3>Prix total : $prixTotal €</h3>";
    echo '</section>';
}

function getCommandeLivres(mysqli $bd, int $commandeId): array {
    $query = "SELECT 
        livre.liID, livre.liTitre, livre.liPrix, livre.liNbPages, livre.liISBN13,
        compo_commande.ccQuantite, editeur.edNom, editeur.edWeb,
        GROUP_CONCAT(CONCAT(auteur.auPrenom, '|', auteur.auNom) SEPARATOR '@') AS auteurs
        FROM commande
        INNER JOIN compo_commande ON commande.coID = compo_commande.ccIDCommande
        INNER JOIN livre ON livre.liID = compo_commande.ccIDLivre
        INNER JOIN editeur ON livre.liIDEditeur = editeur.edID
        INNER JOIN aut_livre ON aut_livre.al_IDLivre = livre.liID
        INNER JOIN auteur ON auteur.auID = aut_livre.al_IDAuteur
        WHERE commande.coID = $commandeId
        GROUP BY livre.liID";
    
    $result = bdSendRequest($bd, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function emailExists(mysqli $bd, string $email): bool {
    $sql = "SELECT cliID FROM client WHERE cliEmail = '$email' AND cliID != " . $_SESSION['cliID'];
    $res = bdSendRequest($bd, $sql);
    return mysqli_num_rows($res) > 0;
}

function getCurrentPassword(mysqli $bd): string {
    $sql = "SELECT cliPassword FROM client WHERE cliID = " . $_SESSION['cliID'];
    $result = bdSendRequest($bd, $sql);
    return mysqli_fetch_assoc($result)['cliPassword'];
}

function updateUserData(mysqli $bd, array $data): void {
    $updates = [];
    foreach ($data as $field => $value) {
        $updates[] = "$field = '$value'";
    }
    
    $sql = "UPDATE client SET " . implode(', ', $updates) . " WHERE cliID = " . $_SESSION['cliID'];
    bdSendRequest($bd, $sql);
}