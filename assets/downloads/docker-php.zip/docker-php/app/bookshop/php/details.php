<?php 
require_once './bibli_generale.php';
require_once './bibli_bookshop.php';

// Bufferisation des sorties
ob_start();

// Démarrage ou reprise de la session
session_start();

// Affichage de l'en-tête
affDebutEnseigneEntete('BookShop | Détail du livre ', '..');

// Affichage du contenu principal
afficherDetailsLivre();

// Affichage du pied de page
affPiedFin();


/**
 * Affiche les détails du livre
 */
function afficherDetailsLivre() {
    $livre = recupererLivreDepuisBDD($_GET['article']);
    if (!$livre) {
        echo '<p>Livre introuvable.</p>';
        return;
    }

    $auteurs = parserAuteurs($livre['auteurs']);
    
    echo '<section>';
    echo '<h2>Détails du livre</h2>';
    echo '<section class="detailLivre">';
    afficherImageLivre($livre['liID']);
    afficherInfosLivre($livre, $auteurs);
    echo '</section>';
    afficherBoutonAjoutPanier($livre);
    echo '</section>';
}


/**
 * Récupère les données du livre depuis la base de données
 */
function recupererLivreDepuisBDD(string $idLivre): ?array {
    $bd = bdConnect();
    $idLivre = mysqli_real_escape_string($bd, $idLivre);

    $sql = "SELECT livre.liID, livre.liTitre, livre.liPrix, livre.liNbPages, livre.liISBN13, 
                   livre.liResume, livre.liAnnee, livre.liCat,
                   editeur.edNom, editeur.edWeb,
                   GROUP_CONCAT(CONCAT(auteur.auPrenom, '|', auteur.auNom) SEPARATOR '@') AS auteurs
            FROM livre
            INNER JOIN editeur ON livre.liIDEditeur = editeur.edID
            INNER JOIN aut_livre ON aut_livre.al_IDLivre = livre.liID
            INNER JOIN auteur ON aut_livre.al_IDAuteur = auteur.auID
            WHERE liID = '$idLivre'
            GROUP BY livre.liID";

    $result = bdSendRequest($bd, $sql);
    $livre = mysqli_fetch_assoc($result);

    mysqli_free_result($result);
    mysqli_close($bd);

    return $livre ?: null;
}

/**
 * Transforme la chaîne d'auteurs en tableau associatif
 */
function parserAuteurs(?string $chaine): array {
    if (empty($chaine)) return [];

    $auteurs = [];
    foreach (explode('@', $chaine) as $auteur) {
        [$prenom, $nom] = explode('|', $auteur);
        $auteurs[] = ['prenom' => $prenom, 'nom' => $nom];
    }
    return $auteurs;
}

/**
 * Affiche l'image du livre
 */
function afficherImageLivre(string $id) {
    echo '<article class="detailImage">';
    echo '<img src="../images/livres/' . htmlspecialchars($id) . '.jpg" alt="Image du livre" width="100">';
    echo '</article>';
}

/**
 * Affiche les informations détaillées du livre
 */
function afficherInfosLivre(array $livre, array $auteurs) {
    echo '<article class="detailTexte">';
    echo '<h3>' . htmlspecialchars($livre['liTitre']) . '</h3>';

    echo '<p>';
    foreach ($auteurs as $auteur) {
        echo htmlspecialchars($auteur['prenom']) . ' ' . htmlspecialchars($auteur['nom']) . '<br>';
    }
    echo '</p>';

    echo '<p><strong>Catégorie :</strong> ' . htmlspecialchars($livre['liCat']) . '</p>';
    echo '<p><strong>Éditeur :</strong> <a href="http://' . htmlspecialchars($livre['edWeb']) . '">' . htmlspecialchars($livre['edNom']) . '</a></p>';
    echo '<p><strong>Date de parution :</strong> ' . htmlspecialchars($livre['liAnnee']) . '</p>';
    echo '<p><strong>Nombre de pages :</strong> ' . htmlspecialchars($livre['liNbPages']) . '</p>';
    echo '<p><strong>Prix :</strong> ' . htmlspecialchars($livre['liPrix']) . ' €</p>';
    echo '<p><strong>Résumé :</strong> ' . htmlspecialchars($livre['liResume']) . '</p>';
    echo '<p><strong>ISBN :</strong> ' . htmlspecialchars($livre['liISBN13']) . '</p>';
    echo '</article>';
}

/**
 * Affiche le bouton d’ajout au panier
 */
function afficherBoutonAjoutPanier(array $livre) {
    $id = urlencode($livre['liID']);
    $titre = urlencode($livre['liTitre']);
    $prix = htmlspecialchars($livre['liPrix']);

    echo '<section class="detailPanier">';
    echo '<h2>Ajouter au panier</h2>';
    echo '<p>Vous pouvez ajouter cet article à votre panier en cliquant sur le bouton ci-dessous.</p>';
    echo '<div><a href="./panier.php?action=ajouter&amp;id=' . $id . '&titre=' . $titre . '&prix=' . $prix . '">Ajouter au panier</a></div>';
    echo '</section>';
}
