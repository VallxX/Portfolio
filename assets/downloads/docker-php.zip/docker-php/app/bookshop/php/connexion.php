<?php 
require_once './bibli_generale.php';
require_once('./bibli_bookshop.php');

// bufferisation des sorties
ob_start();

// démarrage ou reprise de la session
session_start();

// Redirection si l'utilisateur est déjà authentifié
if (estAuthentifie()) {
    header('Location: ../index.php');
    exit();
}

// Initialisation des erreurs
$erreurs = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement de la connexion
    $erreurs = traiterConnexion();
}

// Affichage de la page
afficherPageConnexion($erreurs);

/**
 * Fonction pour afficher la page de connexion
 */
function afficherPageConnexion(array $erreurs) {
    affDebutEnseigneEntete('BookShop | Connexion', '..');
    echo '<form method="post" action="' . basename($_SERVER['PHP_SELF']) . '">';
    afficherErreurs($erreurs);
    afficherFormulaireConnexion();
    echo '</form>';
    affPiedFin();
}

/**
 * Fonction pour afficher les erreurs si présentes
 */
function afficherErreurs(array $erreurs) {
    if (!empty($erreurs)) {
        echo '<p class="error"><strong>Les erreurs suivantes ont été relevées lors de votre connexion :</strong>';
        foreach ($erreurs as $erreur) {
            echo '<br>- ' . $erreur;
        }
        echo '</p>';
    }
}

/**
 * Fonction pour afficher le formulaire de connexion
 */
function afficherFormulaireConnexion() {
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    echo '<section>';
    echo '<h2>Se connecter</h2>';
    echo '<p>Merci de remplir les informations suivantes (tous les champs sont obligatoires)</p>';
    echo '<table>';
    
    // Champ pour l'email
    affLigneInput('Votre adresse email :', array(
        'type' => 'email', 
        'name' => 'email', 
        'value' => $email,
        'placeholder' => 'xxx@yyy.zz', 
        'required' => null
    ));

    // Champ pour le mot de passe
    affLigneInput('Mot de passe :', array(
        'type' => 'password', 
        'name' => 'password', 
        'value' => '',
        'placeholder' => LMIN_PASSWORD . ' caractères minimum', 
        'required' => null
    ));

    echo '</table>';
    echo '<p>Si vous n\'êtes pas encore inscrit : <a href="inscription.php">S\'inscrire</a></p>';

    // Boutons de validation
    echo '<section><h2>Validation</h2><p>';
    echo '<input type="submit" value="Connexion">';
    echo '<input type="reset" value="Réinitialiser">';
    echo '</p></section>';
    echo '</section>';
}

/**
 * Fonction pour traiter la connexion de l'utilisateur
 */
function traiterConnexion(): array {
    $erreurs = [];

    // Vérification des paramètres
    if (!isset($_POST['email'], $_POST['password'])) {
        return ['Données manquantes.'];
    }

    // Sécurisation de l'email
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $bd = bdConnect();
    $email = mysqli_real_escape_string($bd, $email);

    // Vérification dans la base de données
    $sql = "SELECT cliID, cliPassword FROM client WHERE cliEmail = '$email'";
    $res = bdSendRequest($bd, $sql);

    if ($tab = mysqli_fetch_assoc($res)) {
        // Vérification du mot de passe
        if (password_verify($password, $tab['cliPassword'])) {
            $_SESSION['cliID'] = $tab['cliID'];

            // Redirection vers la page précédente ou vers index.php
            rediriger();
        } else {
            $erreurs[] = 'Mot de passe invalide.';
        }
    } else {
        $erreurs[] = 'Adresse email invalide.';
    }

    // Libération de la mémoire et fermeture de la base
    mysqli_free_result($res);
    mysqli_close($bd);

    return $erreurs;
}

/**
 * Fonction de redirection après une connexion réussie
 */
function rediriger() {
    $referer = $_SERVER['HTTP_REFERER'] ?? '../index.php';
    header("Location: $referer");
    exit();
}
