<?php
session_start();
ob_start();

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';
affDebutEnseigneEntete('BookShop | Panier');

if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

$bd = bdConnect();

// Gestion des actions du panier (ajout, modification, suppression)
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'ajouter':
            if (isset($_GET['id'])) {
                $idLivre = (int)$_GET['id'];
                $_SESSION['panier'][$idLivre] = ($_SESSION['panier'][$idLivre] ?? 0) + 1;
            }
            break;
            
        case 'supprimer':
            if (isset($_GET['id'])) {
                $idLivre = (int)$_GET['id'];
                unset($_SESSION['panier'][$idLivre]);
            }
            break;
            
        case 'commander':
            if (!estAuthentifie()) {
                $message = "❌ Veuillez vous <a href='connexion.php'>connecter</a> pour passer commande.";
                break;
            }
            
            $idClient = $_SESSION['cliID'];
            
            // Vérification de l'adresse du client
            $sql = "SELECT cliAdresse, cliCP, cliVille FROM client WHERE cliID = ?";
            $stmt = mysqli_prepare($bd, $sql);
            mysqli_stmt_bind_param($stmt, 'i', $idClient);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $adresse, $cp, $ville);
            mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);
            
            if (empty($adresse) || empty($cp) || empty($ville)) {
                $message = "❌ Vous devez renseigner votre adresse de livraison dans <a href='compte.php'>votre compte</a>.";
                break;
            }
            
            // Calcul du total
            $total = 0;
            foreach ($_SESSION['panier'] as $idLivre => $quantite) {
                $sql = 'SELECT liPrix FROM livre WHERE liID = ?';
                $stmt = mysqli_prepare($bd, $sql);
                mysqli_stmt_bind_param($stmt, 'i', $idLivre);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_bind_result($stmt, $prix);
                mysqli_stmt_fetch($stmt);
                mysqli_stmt_close($stmt);
                $total += $prix * $quantite;
            }
            
            // Insertion de la commande (avec gestion d'erreur améliorée)
            $dateCommande = date('YmdHi'); // Format DATETIME standard
            
            $sql = "INSERT INTO commande (coIDClient, coDate) VALUES (?, ?)";
            $stmt = mysqli_prepare($bd, $sql);
            mysqli_stmt_bind_param($stmt, 'is', $idClient, $dateCommande);
            
            if (!mysqli_stmt_execute($stmt)) {
                error_log("Erreur SQL commande: " . mysqli_error($bd));
                die("Une erreur est survenue lors de la commande. Veuillez réessayer.");
            }
            
            $idCommande = mysqli_insert_id($bd);
            mysqli_stmt_close($stmt);
            
            // Insertion des articles de la commande
            foreach ($_SESSION['panier'] as $idLivre => $quantite) {
                $sql = "INSERT INTO compo_commande (ccIDLivre, ccIDCommande, ccQuantite) VALUES (?, ?, ?)";
                $stmt = mysqli_prepare($bd, $sql);
                mysqli_stmt_bind_param($stmt, 'iii', $idLivre, $idCommande, $quantite);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
            
            $_SESSION['panier'] = [];
            $message = "✅ Commande passée avec succès !";
            break;
    }
    
    // Redirection après action GET pour éviter la resoumission
    header('Location: panier.php');
    exit;
}

// Gestion de la modification de quantité (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'modifier') {
    if (isset($_POST['id']) && isset($_POST['quantite'])) {
        $idLivre = (int)$_POST['id'];
        $quantite = (int)$_POST['quantite'];
        
        if ($quantite > 0) {
            $_SESSION['panier'][$idLivre] = $quantite;
        } else {
            unset($_SESSION['panier'][$idLivre]);
        }
    }
    header('Location: panier.php');
    exit;
}

// Affichage du panier
function afficherPanier($bd) {
    if (empty($_SESSION['panier'])) {
        echo '<p>Votre panier est vide.</p>';
        return;
    }
    
    echo '<table class="table-panier">',
         '<tr><th>Titre</th><th>Quantité</th><th>Prix unitaire</th><th>Total</th><th>Action</th></tr>';
    
    $totalPanier = 0;
    
    foreach ($_SESSION['panier'] as $idLivre => $quantite) {
        $sql = 'SELECT liTitre, liPrix FROM livre WHERE liID = ?';
        $stmt = mysqli_prepare($bd, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $idLivre);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $titre, $prix);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        
        $totalLigne = $prix * $quantite;
        $totalPanier += $totalLigne;
        
        echo '<tr>',
             '<td>', htmlspecialchars($titre), '</td>',
             '<td>',
             '<form method="post" action="panier.php">',
             '<input type="hidden" name="action" value="modifier">',
             '<input type="hidden" name="id" value="', $idLivre, '">',
             '<input type="number" name="quantite" value="', $quantite, '" min="1">',
             '<button type="submit">Mettre à jour</button>',
             '</form>',
             '</td>',
             '<td>', number_format($prix, 2, ',', ' '), ' €</td>',
             '<td>', number_format($totalLigne, 2, ',', ' '), ' €</td>',
             '<td><a href="panier.php?action=supprimer&id=', $idLivre, '" class="btn-supprimer">Supprimer</a></td>',
             '</tr>';
    }
    
    echo '</table>',
         '<div class="total-panier">',
         '<strong>Total du panier : ', number_format($totalPanier, 2, ',', ' '), ' €</strong>',
         '</div>',
         '<div class="actions-panier">',
         '<a href="panier.php?action=commander" class="btn-commander">Passer commande</a>',
         '</div>';
}

// Affichage des messages
if (isset($message)) {
    echo '<div class="message">', $message, '</div>';
}

afficherPanier($bd);
affPiedFin();
mysqli_close($bd);
?>