<?php
//
// Param�tres de l'application
//

/* Une des fa�ons les plus simples de d�finir des param�tres
 * est de d�finir des constantes car elles sont "superglobales"
 */

// Phase de d�veloppement (TRUE) ou de production (FALSE)
// Permet d'afficher des messages de d�buggage (TRUE)
define('IS_DEV', TRUE);

// Param�tres base de donn�es
define('BD_SERVER', 'mariadb-hostname');
define('BD_USER', 'tuto_user');
define('BD_PASS', 'tuto_pass');
define('BD_NAME', 'php_tuto');
