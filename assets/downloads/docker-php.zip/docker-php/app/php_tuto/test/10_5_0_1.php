<?php header('Content-Type: text/html; charset=UTF-8'); ini_set('display_errors', '1'); ini_set('display_startup_errors', '1'); error_reporting(E_ALL); ?><?php
ob_start();
require('bib_params.php');
require('bib_fonctions.php');

htmlDebut('Sélectionner un livre');

$bd = bdConnect();

//-- Requête ----------------------------------------
$sql = 'SELECT liTitre, liAnnee, liPages, liPrix 
		FROM livres
		WHERE liID = 5';
$r = mysqli_query($bd, $sql);

//-- Traitement -------------------------------------
$enr = mysqli_fetch_assoc($r);

infoTableau($enr);

// Libération de la mémoire associée au résultat de la requête
mysqli_free_result($r);
//-- Déconnexion ------------------------------------
mysqli_close($bd);

htmlFin();